# Actions Test 

Repository used to show different GitHub Actions Features

Also used in my [YouTube video](https://youtu.be/w_37LDOy4sI):

## Video

If you want to see an in-depth explanation on the Actions Environments and Approvals, check my video on YouTube:

[![GitHub Actions Environments](https://img.youtube.com/vi/w_37LDOy4sI/0.jpg)](https://www.youtube.com/watch?v=w_37LDOy4sI)

You can also take a look at [my blog post here](https://dev.to/n3wt0n/everything-you-need-to-know-about-github-actions-environments-9p7)
